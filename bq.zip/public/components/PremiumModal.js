export function openPremium(){
  alert('BettyQuotes Pro — presto disponibile: export illimitati, value/sure in anticipo, alert personalizzati.');
}
window.openPremium = openPremium;
